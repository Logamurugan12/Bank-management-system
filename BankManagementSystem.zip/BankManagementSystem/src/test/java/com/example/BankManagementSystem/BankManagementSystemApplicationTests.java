package com.example.BankManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
